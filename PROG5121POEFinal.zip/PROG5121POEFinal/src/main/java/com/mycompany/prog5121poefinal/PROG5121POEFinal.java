/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poefinal;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 *
 * @author emsla
 */
public class PROG5121POEFinal {
       
    private static final Scanner scanner = new Scanner(System.in);
    private static final SecureRandom random = new SecureRandom();

    private static final ArrayList<Login> users = new ArrayList<>();

    // Dynamically populated message collections (nothing is hard-coded).
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();

    private static Login currentUser;
    private static int messageNumber = 0;
    private static int totalMessagesSent = 0;

    private static final String PHONE_REGEX = "\\+27[6-8]\\d{8}";
    private static final Path MESSAGE_FILE = Path.of("messages.json");

    public static void main(String[] args) {
        loadStoredMessages();

        System.out.println("\n[System] Carrier Pigeons are on standby.");
        System.out.println("[System] User database is synced and initialized.");
        System.out.println("[System] Secure connections have been enabled.");
        System.out.println("[System] Bird feed has been divided.");

        System.out.println("======================================");
        System.out.println("        CARRIER PIGEON LOGIN          ");
        System.out.println("======================================");
        System.out.println("  Secure messages, delivered safely.  ");
        System.out.println("======================================");

        boolean running = true;

        while (running) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");

            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> registerUser();
                case 2 -> {
                    if (users.isEmpty()) {
                        System.out.println("No users are registered yet. Please register first.");
                    } else if (promptLogin()) {
                        runMessageSystem();
                    }
                }
                case 3 -> {
                    System.out.println("Returning to the nest.");
                    running = false;
                }
                default -> System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }

        scanner.close();
    }

    private static void registerUser() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();

        boolean validUsername = username.contains("_") && username.length() <= 9;

        if (!validUsername) {
            System.out.println("Username must contain an underscore (_) and be no longer than 9 characters.");
            return;
        }

        boolean userExists = users.stream().anyMatch(u -> u.getUsername().equals(username));

        if (userExists) {
            System.out.println("Username already exists. Please choose another.");
            return;
        }

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        boolean validPassword = password.length() > 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");

        if (!validPassword) {
            System.out.println("Password must be at least 9 characters long and contain an uppercase letter, a number and a special character.");
            return;
        }

        System.out.print("Enter a South African mobile number (e.g. +278311111111): ");
        String phoneNumber = scanner.nextLine().trim();

        if (!phoneNumber.matches(PHONE_REGEX)) {
            System.out.println("Invalid number. Use +27 followed by 9 digits, starting with 6, 7 or 8.");
            return;
        }

        users.add(new Login(username, password, phoneNumber));

        System.out.println("User registered successfully!");
        System.out.println("Welcome " + username + "! Your winged messenger is ready.");
        System.out.println("\nPlease log in to continue.");

        if (promptLogin()) {
            runMessageSystem();
        }
    }

    private static boolean promptLogin() {
        System.out.print("Please enter username: ");
        String enteredUsername = scanner.nextLine().trim();

        Login user = users.stream()
                .filter(u -> u.getUsername().equals(enteredUsername))
                .findFirst()
                .orElse(null);

        if (user == null) {
            System.out.println("Invalid username or password.");
            return false;
        }

        int attempts = 3;

        while (attempts > 0) {
            System.out.print("Please enter password: ");
            String enteredPassword = scanner.nextLine();

            if (user.loginUser(enteredPassword)) {
                currentUser = user;
                System.out.println("Login successful!");
                System.out.println("Welcome back, " + enteredUsername + "!");
                return true;
            }

            attempts--;
            System.out.println("Invalid username or password.");

            if (attempts > 0) {
                System.out.println("Attempts remaining: " + attempts);
            }
        }

        System.out.println("Too many failed attempts. Returning to main menu.");
        return false;
    }

    public static void runMessageSystem() {
        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\n===== MESSAGE SYSTEM =====");
            System.out.println("1. Send messages");
            System.out.println("2. Coming soon");
            System.out.println("3. Quit message system");
            System.out.println("4. Stored Messages");

            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> sendMessages();
                case 2 -> System.out.println("This feature is coming soon.");
                case 3 -> {
                    System.out.println("Farewell! Returning to the main menu.");
                    keepRunning = false;
                }
                case 4 -> storedMessagesMenu();
                default -> System.out.println("Invalid option. Please choose 1, 2, 3 or 4.");
            }
        }
    }

    public static void sendMessages() {
        int count;

        do {
            count = readInt("How many messages would you like to send? ");

            if (count < 1) {
                System.out.println("Enter a number greater than zero.");
            }
        } while (count < 1);

        for (int i = 0; i < count; i++) {
            System.out.println("\nPreparing message " + (i + 1) + " of " + count);

            System.out.print("Enter recipient number (+278311111111): ");
            String recipient = scanner.nextLine().trim();

            if (!recipient.matches(PHONE_REGEX)) {
                System.out.println("Invalid recipient number.");
                i--;
                continue;
            }

            System.out.print("Enter message (maximum 250 characters): ");
            String messageText = scanner.nextLine();

            if (messageText.trim().isEmpty()) {
                System.out.println("Message cannot be blank.");
                i--;
                continue;
            }

            if (messageText.length() > 250) {
                System.out.println("Message exceeds the limit by "
                        + (messageText.length() - 250) + " characters.");
                i--;
                continue;
            }

            messageNumber++;

            String messageID = generateMessageID();
            String hash = generateMessageHash(messageID, messageNumber, messageText);
            String sender = currentUser == null ? "Unknown" : currentUser.getUsername();

            Message newMessage = new Message(sender, recipient, messageText, messageID, hash);

            // Every generated ID and hash is collected, regardless of the selected action.
            messageIDs.add(messageID);
            messageHashes.add(hash);

            System.out.println("\nMessage options:");
            System.out.println("1. Send");
            System.out.println("2. Disregard");
            System.out.println("3. Store");

            int action = readInt("Choose an option: ");

            switch (action) {
                case 1 -> {
                    sentMessages.add(newMessage);
                    totalMessagesSent++;
                    displayMessageDetails(newMessage);
                    System.out.println("Message successfully sent.");
                }
                case 2 -> {
                    disregardedMessages.add(newMessage);
                    System.out.println("Message disregarded.");
                }
                case 3 -> saveStoredMessage(newMessage);
                default -> {
                    System.out.println("Invalid action. Message was not sent or stored.");
                    // Remove IDs and hashes for a message that was not accepted.
                    messageIDs.remove(messageID);
                    messageHashes.remove(hash);
                }
            }
        }

        System.out.println("\nTotal messages sent this session: " + totalMessagesSent);
        System.out.println("Total sent messages in this session: " + sentMessages.size());
        System.out.println("Total disregarded messages in this session: " + disregardedMessages.size());
        System.out.println("Total stored messages currently available: " + storedMessages.size());
    }

    private static void storedMessagesMenu() {
        boolean inMenu = true;

        while (inMenu) {
            System.out.println("\n===== STORED MESSAGES =====");
            System.out.println("1. Display sender and recipient of all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search for a message using its ID");
            System.out.println("4. Search for all messages for a recipient");
            System.out.println("5. Delete a message using its hash");
            System.out.println("6. Display a full report of stored messages");
            System.out.println("7. Return to message menu");

            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> displaySendersAndRecipients();
                case 2 -> displayLongestStoredMessage();
                case 3 -> searchStoredMessageByID();
                case 4 -> searchStoredMessagesByRecipient();
                case 5 -> deleteStoredMessageByHash();
                case 6 -> displayStoredMessagesReport();
                case 7 -> inMenu = false;
                default -> System.out.println("Invalid option. Please choose 1 to 7.");
            }
        }
    }

    // A. Display the sender and recipient of every stored message.
    private static void displaySendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            System.out.println("There are no stored messages.");
            return;
        }

        System.out.println("\n===== STORED MESSAGE SENDERS AND RECIPIENTS =====");

        for (Message message : storedMessages) {
            System.out.println("Sender: " + message.getSender());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("-----------------------------------------------");
        }
    }

    // B. Find and display the longest stored message.
    private static void displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            System.out.println("There are no stored messages.");
            return;
        }

        Message longestMessage = storedMessages.get(0);

        for (Message message : storedMessages) {
            if (message.getMessage().length() > longestMessage.getMessage().length()) {
                longestMessage = message;
            }
        }

        System.out.println("\n===== LONGEST STORED MESSAGE =====");
        displayMessageDetails(longestMessage);
        System.out.println("Message length: " + longestMessage.getMessage().length() + " characters.");
    }

    // C. Search for a stored message by its ID.
    private static void searchStoredMessageByID() {
        System.out.print("Enter the message ID to search for: ");
        String searchID = scanner.nextLine().trim();

        boolean found = false;

        for (Message message : storedMessages) {
            if (message.getMessageID().equalsIgnoreCase(searchID)) {
                System.out.println("\nMessage found:");
                System.out.println("Recipient: " + message.getRecipient());
                System.out.println("Message: " + message.getMessage());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No stored message was found with that ID.");
        }
    }

    // D. Display all stored messages for a particular recipient.
    private static void searchStoredMessagesByRecipient() {
        System.out.print("Enter the recipient number to search for: ");
        String searchRecipient = scanner.nextLine().trim();

        boolean found = false;

        for (Message message : storedMessages) {
            if (message.getRecipient().equalsIgnoreCase(searchRecipient)) {
                System.out.println("\nMessage found:");
                displayMessageDetails(message);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No stored messages were found for that recipient.");
        }
    }

    // E. Delete a stored message by its hash and update the JSON file.
    private static void deleteStoredMessageByHash() {
        System.out.print("Enter the message hash of the message to delete: ");
        String searchHash = scanner.nextLine().trim();

        boolean removed = false;

        for (int i = storedMessages.size() - 1; i >= 0; i--) {
            Message message = storedMessages.get(i);

            if (message.getMessageHash().equalsIgnoreCase(searchHash)) {
                storedMessages.remove(i);
                messageHashes.remove(message.getMessageHash());
                messageIDs.remove(message.getMessageID());
                removed = true;
            }
        }

        if (removed) {
            saveStoredMessagesToJSON();
            System.out.println("Stored message deleted successfully.");
        } else {
            System.out.println("No stored message was found with that hash.");
        }
    }

    // F. Display all details of every stored message.
    private static void displayStoredMessagesReport() {
        if (storedMessages.isEmpty()) {
            System.out.println("There are no stored messages to display.");
            return;
        }

        System.out.println("\n========== STORED MESSAGES REPORT ==========");

        for (int i = 0; i < storedMessages.size(); i++) {
            System.out.println("\nStored message " + (i + 1) + ":");
            displayMessageDetails(storedMessages.get(i));
        }

        System.out.println("\nTotal stored messages: " + storedMessages.size());
        System.out.println("=============================================");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    public static String generateMessageID() {
        return String.format("%010d", random.nextInt(1_000_000_000));
    }

    public static String generateMessageHash(String id, int num, String msg) {
        String trimmed = msg.trim();
        String[] words = trimmed.split("\\s+");

        String first = words[0];
        String last = words[words.length - 1];

        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

    public static void displayMessageDetails(Message message) {
        System.out.println("\n===== MESSAGE DETAILS =====");
        System.out.println("Sender: " + message.getSender());
        System.out.println("Message ID: " + message.getMessageID());
        System.out.println("Message Hash: " + message.getMessageHash());
        System.out.println("Recipient: " + message.getRecipient());
        System.out.println("Message: " + message.getMessage());
        System.out.println("============================");
    }

    // Add a message to the in-memory collection, then save the collection to JSON.
    private static void saveStoredMessage(Message message) {
        storedMessages.add(message);

        if (saveStoredMessagesToJSON()) {
            System.out.println("Message stored successfully.");
        } else {
            // Keep the in-memory collection consistent if the file could not be saved.
            storedMessages.remove(message);
            messageIDs.remove(message.getMessageID());
            messageHashes.remove(message.getMessageHash());
        }
    }

    // Read messages.json into the storedMessages collection.
    private static void loadStoredMessages() {
        if (!Files.exists(MESSAGE_FILE)) {
            System.out.println("[System] No messages.json file found. A new file will be created when a message is stored.");
            return;
        }

        try {
            String jsonText = Files.readString(MESSAGE_FILE, StandardCharsets.UTF_8).trim();

            if (jsonText.isEmpty()) {
                return;
            }

            JSONArray jsonMessages = new JSONArray(jsonText);

            storedMessages.clear();

            for (int i = 0; i < jsonMessages.length(); i++) {
                JSONObject jsonObject = jsonMessages.getJSONObject(i);

                String sender = jsonObject.optString("Sender", "Unknown");
                String recipient = jsonObject.optString("Recipient", "");
                String messageText = jsonObject.optString("Message", "");
                String messageID = jsonObject.optString("MessageID", "");
                String hash = jsonObject.optString("MessageHash", "");

                Message message = new Message(sender, recipient, messageText, messageID, hash);
                storedMessages.add(message);

                if (!messageID.isEmpty() && !messageIDs.contains(messageID)) {
                    messageIDs.add(messageID);
                }

                if (!hash.isEmpty() && !messageHashes.contains(hash)) {
                    messageHashes.add(hash);
                }
            }

            messageNumber = Math.max(messageNumber, storedMessages.size());
            System.out.println("[System] Loaded " + storedMessages.size() + " stored message(s) from messages.json.");

        } catch (Exception e) {
            System.out.println("Error reading stored messages: " + e.getMessage());
        }
    }

    // Rewrite the JSON file from the current storedMessages collection.
    private static boolean saveStoredMessagesToJSON() {
        JSONArray jsonMessages = new JSONArray();

        for (Message message : storedMessages) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Sender", message.getSender());
            jsonObject.put("MessageID", message.getMessageID());
            jsonObject.put("MessageHash", message.getMessageHash());
            jsonObject.put("Recipient", message.getRecipient());
            jsonObject.put("Message", message.getMessage());
            jsonMessages.put(jsonObject);
        }

        try {
            Files.writeString(
                    MESSAGE_FILE,
                    jsonMessages.toString(4),
                    StandardCharsets.UTF_8
            );

            System.out.println("Messages saved to " + MESSAGE_FILE.toAbsolutePath());
            return true;

        } catch (IOException e) {
            System.out.println("Error writing message file: " + e.getMessage());
            return false;
        }
    }
}

// Holds all the details belonging to one message.
class Message {

    private final String sender;
    private final String recipient;
    private final String message;
    private final String messageID;
    private final String messageHash;

    public Message(String sender, String recipient, String message,
                   String messageID, String messageHash) {
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.messageID = messageID;
        this.messageHash = messageHash;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }
}

class Login {

    private final String username;
    private final String passwordHash;
    private final String phoneNumber;
    private final byte[] salt;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean loginUser(String enteredPassword) {
        return this.passwordHash.equals(hashPassword(enteredPassword, this.salt));
    }

    private String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);

            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                hexString.append(String.format("%02x", b & 0xff));
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Error hashing password.", e);
        }
    }

    private byte[] generateSalt() {
        byte[] generatedSalt = new byte[16];
        new SecureRandom().nextBytes(generatedSalt);
        return generatedSalt;
    }
    }
