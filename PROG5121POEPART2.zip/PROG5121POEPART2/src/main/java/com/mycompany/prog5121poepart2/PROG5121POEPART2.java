/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poepart2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author emsla
 */
public class PROG5121POEPART2 {
    private static final Scanner scanner = new Scanner(System.in);
    private static final SecureRandom random = new SecureRandom();
     
    private static final ArrayList<Login> users = new ArrayList<>();  //Store the list of users
    private static int messageNumber = 0;
    private static int totalMessagesSent = 0;

    private static final String PHONE_REGEX = "\\+27[6-8]\\d{8}";
    private static final Path MESSAGE_FILE = Path.of("messages.json");
    
    public static void main(String[] args) {
        System.out.println("\n[System] Carrier Pigeons are on standby.");
        System.out.println("[System] User database is synced and initialized.");
        System.out.println("[System] Secure connections have been enabled.");
        System.out.println("[System] Bird feed has been divided.");
        
        System.out.println("======================================");
        System.out.println("        CARRIER PIGEON LOGIN          ");
        System.out.println("======================================");
        System.out.println("  Secure messages, delivered safely.  ");
        System.out.println("======================================");
        
        boolean running = true;
       
        while(running){
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Choose an option:"); //display menu
           
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> registerUser(); //Registry

                case 2 -> {
                    if (users.isEmpty()) {
                        System.out.println("No users are registered yet. Please register first.");
                    } else if (promptLogin()) {
                        runMessageSystem();
                    }
                }

                case 3 -> {
                    System.out.println("Returning to the nest.");
                    running = false; //Exit
                }

                default -> System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }
        scanner.close();
    }
    private static void registerUser() {

        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();

        boolean validUsername = username.contains("_") && username.length() <= 9; //confirmation of username format

        if (!validUsername) {
            System.out.println("Username must contain an underscore (_) " + "and be no longer than 9 characters.");
            return;
        }

        boolean userExists = users.stream().anyMatch(u -> u.getUsername().equals(username));

        if (userExists) {
            System.out.println("Username already exists. Please choose another.");
            return;
        }
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        boolean validPassword = password.length() > 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") 
                && password.matches(".*[!@#$%^&*(),.?\":{}|<>].*"); //Confirmation of password format

        if (!validPassword) {
            System.out.println("Password must be at least 9 characters long " + "and contain an uppercase letter, a number " + "and a special character.");
            return;
        }

        System.out.print("Enter a South African mobile number " + "(e.g. +278311111111): ");

        String phoneNumber = scanner.nextLine().trim();

        if (!phoneNumber.matches(PHONE_REGEX)) {
            System.out.println("Invalid number. Use +27 followed by " + "9 digits, starting with 6, 7 or 8."); //confirmation of phone number format
            return;
        }

        users.add(new Login(username, password, phoneNumber));

        System.out.println("User registered successfully!");
        System.out.println("Welcome " + username + "! Your winged messenger is ready."); //add the new user to the user database

        System.out.println("\nPlease log in to continue.");

        if (promptLogin()) { //Prompt user login
            runMessageSystem();
        }
    }
        
        private static boolean promptLogin() {

        System.out.print("Please enter username: "); //login
        String enteredUsername = scanner.nextLine().trim();

        Login user = users.stream().filter(u -> u.getUsername().equals(enteredUsername)).findFirst().orElse(null);

        if (user == null) {
            System.out.println("Invalid username or password.");
            return false;
        }

        int attempts = 3;

        while (attempts > 0) {
            System.out.print("Please enter password: ");
            String enteredPassword = scanner.nextLine();

            if (user.loginUser(enteredPassword)) {
                System.out.println("Login successful!");
                System.out.println("Welcome back, " + enteredUsername + "!");
                return true;
            }

            attempts--;
            System.out.println("Invalid username or password.");

            if (attempts > 0) {
                System.out.println("Attempts remaining: " + attempts);
            }
        }

        System.out.println("Too many failed attempts. Returning to main menu.");
        return false;
    }
    
    public static void runMessageSystem() {

        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\n===== MESSAGE SYSTEM =====");
            System.out.println("1. Send messages");
            System.out.println("2. Coming soon");
            System.out.println("3. Quit message system");

            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> sendMessages();

                case 2 -> System.out.println("This feature is coming soon.");

                case 3 -> {
                    System.out.println("Farewell! Returning to the main menu.");
                    keepRunning = false;
                }

                default -> System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }
    
    public static void sendMessages() {

        int count;

        do {
            count = readInt("How many messages would you like to send?");

            if (count < 1) {
                System.out.println("Enter a number greater than zero.");
            }
        } while (count < 1);

        for (int i = 0; i < count; i++) {

            System.out.println("\nPreparing message " + (i + 1) + " of " + count);

            System.out.print("Enter recipient number (+278311111111): ");
            String recipient = scanner.nextLine().trim();

            if (!recipient.matches(PHONE_REGEX)) {
                System.out.println("Invalid recipient number.");
                i--;
                continue;
            }

            System.out.print("Enter message (maximum 250 characters): ");
            String message = scanner.nextLine();

            if (message.trim().isEmpty()) {
                System.out.println("Message cannot be blank.");
                i--;
                continue;
            }

            if (message.length() > 250) {
                System.out.println("Message exceeds the limit by " + (message.length() - 250) + " characters.");
                i--;
                continue;
            }
         // Increment only after validation succeeds.
            messageNumber++;

            String messageID = generateMessageID();
            String hash = generateMessageHash(messageID, messageNumber, message);

            System.out.println("\nMessage options:");
            System.out.println("1. Send");
            System.out.println("2. Disregard");
            System.out.println("3. Store");

            int action = readInt("Choose an option: ");

            switch (action) {
                case 1 -> {
                    totalMessagesSent++;
                    displayMessageDetails(messageID, hash, recipient, message);
                    System.out.println("Message successfully sent.");
                }

                case 2 -> System.out.println("Message disregarded.");

                case 3 -> {writeMessageToJSON(messageID, hash, recipient, message);
                }

                default -> System.out.println("Invalid action. Message was not sent or stored.");
            }
        }

        System.out.println("\nTotal messages sent this session: "+ totalMessagesSent);
    }
    
    private static int readInt(String prompt) {

        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }
    
    public static String generateMessageID() {
    return String.format("%010d", random.nextInt(1_000_000_000));
    } // Generate a 10-digit message ID
    
    public static String generateMessageHash(String id, int num, String msg) {

        String trimmed = msg.trim();

        String[] words = trimmed.split("\\s+");

        String first = words[0];
        String last = words[words.length - 1];

        return (id.substring(0, 2) + ":" + num + ":"+ first + last).toUpperCase();
    }
    
    public static void displayMessageDetails(String id, String hash,String recipient, String message) {

        System.out.println("\n===== MESSAGE DETAILS =====");
        System.out.println("Message ID: " + id);
        System.out.println("Message Hash: " + hash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
        System.out.println("============================");
    }
    
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {

        String jsonEntry = "  {\n" + "    \"MessageID\": \"" + escapeJson(messageID) + "\",\n" + "    \"MessageHash\": \"" + escapeJson(hash) + "\",\n"
                          + "    \"Recipient\": \"" + escapeJson(recipient) + "\",\n" + "    \"Message\": \"" + escapeJson(message) + "\"\n" + "  }";

        try {String existing;
            if (Files.exists(MESSAGE_FILE)) {
                existing = Files.readString(MESSAGE_FILE, StandardCharsets.UTF_8).trim();
            } else {existing = "[]";
            }

            if (existing.isEmpty()) {
                existing = "[]";
            }

            if (!existing.startsWith("[") || !existing.endsWith("]")) {
                throw new IOException("Existing file is not a JSON array.");
            }

            String contents = existing.substring(1, existing.length() - 1).trim();
            String updated;

            if (contents.isEmpty()) {
                updated = "[\n" + jsonEntry + "\n]\n";
            } else {
                updated = "[\n" + contents + ",\n" + jsonEntry + "\n]\n";
            }

            Files.writeString(MESSAGE_FILE, updated, StandardCharsets.UTF_8);

            System.out.println("Message stored in " + MESSAGE_FILE.toAbsolutePath());

        } catch (IOException e) {
            System.out.println("Error writing message file: " + e.getMessage());
        }
    }
    
    private static String escapeJson(String value) {

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}

class Login {

    private final String username;
    private final String passwordHash;
    private final String phoneNumber;
    private final byte[] salt;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean loginUser(String enteredPassword) {
        return this.passwordHash.equals(hashPassword(enteredPassword, this.salt));
    }

    private String hashPassword(String password, byte[] salt) {

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);

            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                hexString.append(String.format("%02x", b & 0xff));
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Error hashing password.", e);
        }
    }

    private byte[] generateSalt() {

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }
}